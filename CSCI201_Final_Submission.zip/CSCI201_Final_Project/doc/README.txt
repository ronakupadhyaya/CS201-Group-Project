Name: Ronak Upadhyaya, Mai-Nhien Dang, Chaokang Wu, Kate Livingston, Varduhi Kabbajyan
Email: rdupadhy@usc.edu, mainhied@usc.edu, chaokanw@usc.edu, katelivi@usc.edu, kababjya@usc.edu
Lecture Session Number: 29909R

The Java src contains 1 package (Test) which contains classes containing methods for handling web application logic.
The WebContent folder contains folders for css (css), image resources (img), JS scripts (js). 
The lib folder inside WEB-INF contains the .jar package that is the Java driver for MongoDB.
All jsps and html files are contained in the WebContent folder.

Some href links provided in switch.html are redundant, while a few links need to be updated.
Display of some webpages need to be refurnished.